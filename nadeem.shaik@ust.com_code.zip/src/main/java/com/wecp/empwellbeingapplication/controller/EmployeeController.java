package com.wecp.empwellbeingapplication.controller;


import com.wecp.empwellbeingapplication.entity.Employee;
import com.wecp.empwellbeingapplication.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {


   @Autowired 
   private EmployeeService employeeService;

   @PostMapping()
    public Employee registerEmployee(@RequestBody Employee employee) {
      return employeeService.registerEmployee(employee);
       // register employee
    }

    @DeleteMapping("{employeeId}")
    public void deleteEmployee(@PathVariable Long employeeId) {
      employeeService.deleteEmployee(employeeId);
       // delete employee
    }


    @GetMapping()
    public List<Employee> getAllEmployees() {
      return employeeService.getAllEmployees();
      // get all employees
    }

}
