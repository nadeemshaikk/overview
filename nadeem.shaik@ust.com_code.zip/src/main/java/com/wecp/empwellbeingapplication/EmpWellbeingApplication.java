package com.wecp.empwellbeingapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpWellbeingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpWellbeingApplication.class, args);
	}

}
