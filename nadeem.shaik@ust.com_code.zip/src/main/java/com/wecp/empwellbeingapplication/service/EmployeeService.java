package com.wecp.empwellbeingapplication.service;


import com.wecp.empwellbeingapplication.entity.Employee;
import com.wecp.empwellbeingapplication.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee registerEmployee(Employee employee) {
      return employeeRepository.save(employee);
       // register employee
    }

    public void deleteEmployee(Long employeeId) {
      employeeRepository.deleteById(employeeId);
      // delete employee
    }

    public List<Employee> getAllEmployees() {
      return employeeRepository.findAll();
       // get all employees
    }
}