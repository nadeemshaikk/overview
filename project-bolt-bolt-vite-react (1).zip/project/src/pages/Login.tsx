import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Lock } from 'lucide-react';

export default function Login() {
  return (
    <div className="min-h-screen bg-black text-white pt-24">
      <div className="max-w-md mx-auto px-4">
        <div className="bg-gray-900 rounded-xl p-8">
          <h1 className="text-3xl font-bold text-center mb-8">Welcome Back</h1>
          
          <form className="space-y-6">
            <div className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  placeholder="Email Address"
                  className="w-full pl-10 pr-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="password"
                  placeholder="Password"
                  className="w-full pl-10 pr-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input type="checkbox" className="form-checkbox h-4 w-4 text-amber-500" />
                <span className="ml-2 text-sm text-gray-400">Remember me</span>
              </label>
              <Link to="/forgot-password" className="text-sm text-amber-500 hover:text-amber-400">
                Forgot Password?
              </Link>
            </div>

            <button
              type="submit"
              className="w-full bg-amber-500 text-black py-3 rounded-full hover:bg-amber-400 transition-colors font-semibold"
            >
              Sign In
            </button>

            <div className="text-center text-gray-400">
              Don't have an account?{' '}
              <Link to="/register" className="text-amber-500 hover:text-amber-400">
                Sign Up
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}