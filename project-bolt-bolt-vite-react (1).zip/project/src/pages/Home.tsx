import React from 'react';
import { Car, ChevronRight, Star, MessageSquare, Shield, Truck, CreditCard } from 'lucide-react';

function Home() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div 
        className="relative h-screen bg-cover bg-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=80&w=2069")'
        }}
      >
        <div className="absolute inset-0 bg-black/60" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center max-w-4xl px-4">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Smart Vehicle Resale & Service Platform
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-300">
              Your Trusted Platform for Premium Used Cars
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button className="bg-amber-500 text-black px-8 py-3 rounded-full text-lg font-semibold hover:bg-amber-400 transition-colors">
                Explore Cars
              </button>
              <button className="bg-transparent border-2 border-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-white/10 transition-colors">
                Sell Your Car
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Car, title: "Choose a Car", desc: "Browse our curated selection of luxury vehicles" },
              { icon: MessageSquare, title: "Contact Us", desc: "Speak with our automotive experts" },
              { icon: CreditCard, title: "Secure Payment", desc: "Safe and transparent transactions" },
              { icon: Truck, title: "Door Delivery", desc: "Get your car delivered to your doorstep" }
            ].map((step, index) => (
              <div key={index} className="bg-black/50 p-6 rounded-xl text-center hover:transform hover:scale-105 transition-transform">
                <div className="flex justify-center mb-4">
                  <step.icon className="w-12 h-12 text-amber-500" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Cars */}
      <section className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Featured Vehicles</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                image: "https://images.unsplash.com/photo-1617654112368-307921291f42?auto=format&fit=crop&q=80&w=1000",
                name: "Mercedes-Benz S-Class",
                price: "$85,000",
                year: "2022",
                rating: 5
              },
              {
                image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=80&w=1000",
                name: "BMW 7 Series",
                price: "$78,000",
                year: "2021",
                rating: 5
              },
              {
                image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&q=80&w=1000",
                name: "Audi A8",
                price: "$82,000",
                year: "2022",
                rating: 5
              }
            ].map((car, index) => (
              <div key={index} className="bg-gray-900 rounded-xl overflow-hidden group">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={car.image} 
                    alt={car.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4 bg-amber-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
                    {car.year}
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-semibold">{car.name}</h3>
                    <div className="flex items-center">
                      <Star className="w-5 h-5 text-amber-500 fill-current" />
                      <span className="ml-1">{car.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-amber-500">{car.price}</span>
                    <button className="flex items-center text-amber-500 hover:text-amber-400 transition-colors">
                      View Details
                      <ChevronRight className="w-5 h-5 ml-1" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col items-center">
              <Shield className="w-16 h-16 text-amber-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Verified Vehicles</h3>
              <p className="text-gray-400">Every car undergoes a rigorous inspection process</p>
            </div>
            <div className="flex flex-col items-center">
              <CreditCard className="w-16 h-16 text-amber-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Secure Payments</h3>
              <p className="text-gray-400">Safe and transparent financial transactions</p>
            </div>
            <div className="flex flex-col items-center">
              <Truck className="w-16 h-16 text-amber-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Door Delivery</h3>
              <p className="text-gray-400">Convenient delivery to your location</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Car className="w-8 h-8 text-amber-500" />
                <span className="text-2xl font-bold">LuxAuto</span>
              </div>
              <p className="text-gray-400">Your trusted platform for premium used cars.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-amber-500 transition-colors">Buy Cars</a></li>
                <li><a href="#" className="hover:text-amber-500 transition-colors">Sell Your Car</a></li>
                <li><a href="#" className="hover:text-amber-500 transition-colors">Car Services</a></li>
                <li><a href="#" className="hover:text-amber-500 transition-colors">Compare Cars</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: contact@luxauto.com</li>
                <li>Phone: +1 (555) 123-4567</li>
                <li>Address: 123 Luxury Lane</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Newsletter</h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-gray-900 text-white px-4 py-2 rounded-l-full focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <button className="bg-amber-500 text-black px-6 py-2 rounded-r-full hover:bg-amber-400 transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
            <p>&copy; 2025 LuxAuto. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default Home;