import React from 'react';
import { Upload, Camera } from 'lucide-react';

export default function Sell() {
  return (
    <div className="min-h-screen bg-black text-white pt-24">
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8 text-center">Sell Your Luxury Vehicle</h1>
        
        <div className="bg-gray-900 rounded-xl p-8">
          <form className="space-y-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold mb-4">Personal Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="First Name"
                  className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <input
                  type="text"
                  placeholder="Last Name"
                  className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <input
                type="email"
                placeholder="Email Address"
                className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <input
                type="tel"
                placeholder="Phone Number"
                className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Vehicle Information */}
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold mb-4">Vehicle Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Make"
                  className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <input
                  type="text"
                  placeholder="Model"
                  className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <input
                  type="number"
                  placeholder="Year"
                  className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <input
                  type="number"
                  placeholder="Mileage"
                  className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* Upload Section */}
            <div className="space-y-4">
              <h2 className="text-2xl font-semibold mb-4">Upload Documents & Photos</h2>
              
              {/* Document Upload */}
              <div className="border-2 border-dashed border-gray-700 rounded-lg p-6 text-center">
                <Upload className="w-12 h-12 mx-auto mb-4 text-amber-500" />
                <p className="text-gray-400 mb-2">Upload vehicle documents</p>
                <input type="file" className="hidden" id="document-upload" />
                <label
                  htmlFor="document-upload"
                  className="bg-amber-500 text-black px-6 py-2 rounded-full hover:bg-amber-400 transition-colors inline-block cursor-pointer"
                >
                  Choose Files
                </label>
              </div>

              {/* Photo Upload */}
              <div className="border-2 border-dashed border-gray-700 rounded-lg p-6 text-center">
                <Camera className="w-12 h-12 mx-auto mb-4 text-amber-500" />
                <p className="text-gray-400 mb-2">Upload vehicle photos</p>
                <input type="file" className="hidden" id="photo-upload" multiple />
                <label
                  htmlFor="photo-upload"
                  className="bg-amber-500 text-black px-6 py-2 rounded-full hover:bg-amber-400 transition-colors inline-block cursor-pointer"
                >
                  Choose Photos
                </label>
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-amber-500 text-black py-3 rounded-full hover:bg-amber-400 transition-colors font-semibold"
            >
              Submit Listing
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}