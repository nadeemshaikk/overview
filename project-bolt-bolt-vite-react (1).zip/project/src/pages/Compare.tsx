import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';

export default function Compare() {
  const [selectedCars, setSelectedCars] = useState<number[]>([]);

  const availableCars = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1617654112368-307921291f42?auto=format&fit=crop&q=80&w=1000",
      name: "Mercedes-Benz S-Class",
      year: "2022",
      price: "$85,000",
      engine: "3.0L V6",
      power: "429 hp",
      transmission: "9-speed automatic"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=80&w=1000",
      name: "BMW 7 Series",
      year: "2021",
      price: "$78,000",
      engine: "3.0L I6",
      power: "335 hp",
      transmission: "8-speed automatic"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&q=80&w=1000",
      name: "Audi A8",
      year: "2022",
      price: "$82,000",
      engine: "3.0L V6",
      power: "335 hp",
      transmission: "8-speed automatic"
    }
  ];

  const handleCarSelect = (carId: number) => {
    if (selectedCars.includes(carId)) {
      setSelectedCars(selectedCars.filter(id => id !== carId));
    } else if (selectedCars.length < 3) {
      setSelectedCars([...selectedCars, carId]);
    }
  };

  const selectedCarsData = availableCars.filter(car => selectedCars.includes(car.id));

  return (
    <div className="min-h-screen bg-black text-white pt-24">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8 text-center">Compare Vehicles</h1>

        {/* Car Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {availableCars.map(car => (
            <div
              key={car.id}
              className={`bg-gray-900 rounded-xl overflow-hidden cursor-pointer transition-transform hover:scale-105 ${
                selectedCars.includes(car.id) ? 'ring-2 ring-amber-500' : ''
              }`}
              onClick={() => handleCarSelect(car.id)}
            >
              <div className="relative h-48">
                <img
                  src={car.image}
                  alt={car.name}
                  className="w-full h-full object-cover"
                />
                {selectedCars.includes(car.id) ? (
                  <div className="absolute top-4 right-4 bg-amber-500 text-black p-2 rounded-full">
                    <X className="w-4 h-4" />
                  </div>
                ) : (
                  <div className="absolute top-4 right-4 bg-white/20 text-white p-2 rounded-full">
                    <Plus className="w-4 h-4" />
                  </div>
                )}
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{car.name}</h3>
                <p className="text-gray-400">{car.year}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        {selectedCarsData.length > 0 && (
          <div className="bg-gray-900 rounded-xl p-8 overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="text-left py-4 px-6">Specifications</th>
                  {selectedCarsData.map(car => (
                    <th key={car.id} className="text-left py-4 px-6">{car.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                <tr>
                  <td className="py-4 px-6 text-gray-400">Price</td>
                  {selectedCarsData.map(car => (
                    <td key={car.id} className="py-4 px-6">{car.price}</td>
                  ))}
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-400">Engine</td>
                  {selectedCarsData.map(car => (
                    <td key={car.id} className="py-4 px-6">{car.engine}</td>
                  ))}
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-400">Power</td>
                  {selectedCarsData.map(car => (
                    <td key={car.id} className="py-4 px-6">{car.power}</td>
                  ))}
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-400">Transmission</td>
                  {selectedCarsData.map(car => (
                    <td key={car.id} className="py-4 px-6">{car.transmission}</td>
                  ))}
                </tr>
              </tbody>
            </table>

            <div className="mt-8 text-center">
              <button className="bg-amber-500 text-black px-8 py-3 rounded-full hover:bg-amber-400 transition-colors">
                Generate Detailed Report
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}