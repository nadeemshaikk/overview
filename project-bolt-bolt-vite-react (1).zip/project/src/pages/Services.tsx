import React from 'react';
import { Wrench, Clock, Calendar } from 'lucide-react';

export default function Services() {
  const services = [
    {
      name: "Premium Maintenance",
      description: "Comprehensive maintenance service for luxury vehicles",
      price: "$299",
      duration: "4-5 hours"
    },
    {
      name: "Interior Detailing",
      description: "Complete interior cleaning and restoration",
      price: "$199",
      duration: "2-3 hours"
    },
    {
      name: "Performance Tuning",
      description: "Custom performance optimization for your vehicle",
      price: "$499",
      duration: "5-6 hours"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white pt-24">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-8 text-center">Luxury Vehicle Services</h1>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <div key={index} className="bg-gray-900 rounded-xl p-6 hover:transform hover:scale-105 transition-transform">
              <Wrench className="w-12 h-12 text-amber-500 mb-4" />
              <h3 className="text-xl font-semibold mb-2">{service.name}</h3>
              <p className="text-gray-400 mb-4">{service.description}</p>
              <div className="flex justify-between items-center mb-4">
                <span className="text-2xl font-bold text-amber-500">{service.price}</span>
                <div className="flex items-center text-gray-400">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>{service.duration}</span>
                </div>
              </div>
              <button className="w-full bg-amber-500 text-black py-2 rounded-full hover:bg-amber-400 transition-colors">
                Book Now
              </button>
            </div>
          ))}
        </div>

        {/* Booking Form */}
        <div className="max-w-3xl mx-auto bg-gray-900 rounded-xl p-8">
          <h2 className="text-2xl font-semibold mb-6">Schedule a Service</h2>
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Full Name"
                className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
              <input
                type="email"
                placeholder="Email Address"
                className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="date"
                  className="w-full pl-10 pr-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <select className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500">
                <option value="">Select Service</option>
                <option value="maintenance">Premium Maintenance</option>
                <option value="detailing">Interior Detailing</option>
                <option value="tuning">Performance Tuning</option>
              </select>
            </div>
            <textarea
              placeholder="Additional Notes"
              rows={4}
              className="w-full px-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
            ></textarea>
            <button
              type="submit"
              className="w-full bg-amber-500 text-black py-3 rounded-full hover:bg-amber-400 transition-colors font-semibold"
            >
              Schedule Service
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}