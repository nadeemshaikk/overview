import React from 'react';
import { Search, Filter } from 'lucide-react';

export default function Buy() {
  const cars = [
    {
      image: "https://images.unsplash.com/photo-1617654112368-307921291f42?auto=format&fit=crop&q=80&w=1000",
      name: "Mercedes-Benz S-Class",
      price: "$85,000",
      year: "2022",
      location: "New York",
      mileage: "15,000 mi"
    },
    {
      image: "https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&q=80&w=1000",
      name: "BMW 7 Series",
      price: "$78,000",
      year: "2021",
      location: "Los Angeles",
      mileage: "20,000 mi"
    },
    {
      image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?auto=format&fit=crop&q=80&w=1000",
      name: "Audi A8",
      price: "$82,000",
      year: "2022",
      location: "Miami",
      mileage: "18,000 mi"
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white pt-24">
      <div className="max-w-7xl mx-auto px-4">
        {/* Search and Filter Section */}
        <div className="bg-gray-900 p-6 rounded-xl mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search by make, model, or keyword"
                className="w-full pl-10 pr-4 py-2 bg-black rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
            <button className="flex items-center justify-center space-x-2 bg-amber-500 text-black px-6 py-2 rounded-lg hover:bg-amber-400 transition-colors">
              <Filter className="w-5 h-5" />
              <span>Filters</span>
            </button>
          </div>
        </div>

        {/* Cars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {cars.map((car, index) => (
            <div key={index} className="bg-gray-900 rounded-xl overflow-hidden group">
              <div className="relative h-48">
                <img 
                  src={car.image}
                  alt={car.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-amber-500 text-black px-3 py-1 rounded-full text-sm font-semibold">
                  {car.year}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{car.name}</h3>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-2xl font-bold text-amber-500">{car.price}</span>
                  <span className="text-gray-400">{car.mileage}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">{car.location}</span>
                  <button className="bg-amber-500 text-black px-4 py-2 rounded-full hover:bg-amber-400 transition-colors">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}