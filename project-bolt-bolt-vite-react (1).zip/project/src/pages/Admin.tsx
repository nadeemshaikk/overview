import React, { useState } from 'react';
import { Bell, Users, Car, Settings, ChevronRight } from 'lucide-react';

export default function Admin() {
  const [notifications, setNotifications] = useState([
    { id: 1, message: 'New car listing request', time: '5 min ago' },
    { id: 2, message: 'User reported an issue', time: '1 hour ago' },
  ]);

  const stats = [
    { label: 'Total Users', value: '1,234', icon: Users },
    { label: 'Active Listings', value: '56', icon: Car },
    { label: 'Pending Reviews', value: '23', icon: Bell },
  ];

  return (
    <div className="min-h-screen bg-black text-white pt-24">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <div className="w-full md:w-64 bg-gray-900 rounded-xl p-6">
            <h2 className="text-xl font-semibold mb-6">Dashboard</h2>
            <nav className="space-y-2">
              <button className="w-full flex items-center space-x-3 text-amber-500 bg-amber-500/10 p-3 rounded-lg">
                <Bell className="w-5 h-5" />
                <span>Notifications</span>
              </button>
              <button className="w-full flex items-center space-x-3 text-gray-400 hover:bg-gray-800 p-3 rounded-lg">
                <Users className="w-5 h-5" />
                <span>Users</span>
              </button>
              <button className="w-full flex items-center space-x-3 text-gray-400 hover:bg-gray-800 p-3 rounded-lg">
                <Car className="w-5 h-5" />
                <span>Listings</span>
              </button>
              <button className="w-full flex items-center space-x-3 text-gray-400 hover:bg-gray-800 p-3 rounded-lg">
                <Settings className="w-5 h-5" />
                <span>Settings</span>
              </button>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1 space-y-8">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="bg-gray-900 rounded-xl p-6">
                  <div className="flex items-center justify-between">
                    <stat.icon className="w-8 h-8 text-amber-500" />
                    <span className="text-3xl font-bold">{stat.value}</span>
                  </div>
                  <p className="mt-2 text-gray-400">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Notifications */}
            <div className="bg-gray-900 rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-6">Recent Notifications</h3>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className="flex items-center justify-between bg-gray-800 p-4 rounded-lg"
                  >
                    <div>
                      <p className="font-medium">{notification.message}</p>
                      <p className="text-sm text-gray-400">{notification.time}</p>
                    </div>
                    <button className="text-amber-500 hover:text-amber-400">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gray-900 rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-6">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button className="flex items-center justify-between bg-amber-500 text-black p-4 rounded-lg hover:bg-amber-400 transition-colors">
                  <span>Send Notification</span>
                  <Bell className="w-5 h-5" />
                </button>
                <button className="flex items-center justify-between bg-gray-800 p-4 rounded-lg hover:bg-gray-700 transition-colors">
                  <span>Review Listings</span>
                  <Car className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}