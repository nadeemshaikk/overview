import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Car, Menu, X, Heart, User } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { wishlist, isAdmin } = useStore();

  return (
    <nav className="fixed w-full bg-black/95 backdrop-blur-sm z-50 px-4 py-4 border-b border-gray-800">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Car className="w-8 h-8 text-amber-500" />
          <span className="text-2xl font-bold text-white">LuxAuto</span>
        </Link>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link to="/buy" className="text-white hover:text-amber-500 transition-colors">Buy</Link>
          <Link to="/sell" className="text-white hover:text-amber-500 transition-colors">Sell</Link>
          <Link to="/services" className="text-white hover:text-amber-500 transition-colors">Services</Link>
          <Link to="/compare" className="text-white hover:text-amber-500 transition-colors">Compare</Link>
          <Link to="/contact" className="text-white hover:text-amber-500 transition-colors">Contact</Link>
          <Link to="/wishlist" className="relative text-white hover:text-amber-500 transition-colors">
            <Heart className="w-6 h-6" />
            {wishlist.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-amber-500 text-black w-5 h-5 rounded-full flex items-center justify-center text-xs">
                {wishlist.length}
              </span>
            )}
          </Link>
          {isAdmin ? (
            <Link to="/admin" className="text-white hover:text-amber-500 transition-colors">
              <User className="w-6 h-6" />
            </Link>
          ) : (
            <Link to="/login" className="bg-amber-500 text-black px-6 py-2 rounded-full hover:bg-amber-400 transition-colors">
              Login
            </Link>
          )}
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-black/95 border-b border-gray-800 md:hidden">
            <div className="flex flex-col space-y-4 p-4">
              <Link to="/buy" className="text-white hover:text-amber-500 transition-colors">Buy</Link>
              <Link to="/sell" className="text-white hover:text-amber-500 transition-colors">Sell</Link>
              <Link to="/services" className="text-white hover:text-amber-500 transition-colors">Services</Link>
              <Link to="/compare" className="text-white hover:text-amber-500 transition-colors">Compare</Link>
              <Link to="/contact" className="text-white hover:text-amber-500 transition-colors">Contact</Link>
              <Link to="/wishlist" className="text-white hover:text-amber-500 transition-colors flex items-center">
                <Heart className="w-6 h-6 mr-2" />
                Wishlist {wishlist.length > 0 && `(${wishlist.length})`}
              </Link>
              {isAdmin ? (
                <Link to="/admin" className="text-white hover:text-amber-500 transition-colors flex items-center">
                  <User className="w-6 h-6 mr-2" />
                  Admin Dashboard
                </Link>
              ) : (
                <Link to="/login" className="bg-amber-500 text-black px-6 py-2 rounded-full hover:bg-amber-400 transition-colors text-center">
                  Login
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}