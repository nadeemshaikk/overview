import { create } from 'zustand';

interface WishlistItem {
  id: number;
  name: string;
  price: string;
  image: string;
}

interface Store {
  wishlist: WishlistItem[];
  addToWishlist: (item: WishlistItem) => void;
  removeFromWishlist: (id: number) => void;
  isAdmin: boolean;
  setIsAdmin: (value: boolean) => void;
}

export const useStore = create<Store>((set) => ({
  wishlist: [],
  addToWishlist: (item) => 
    set((state) => ({ 
      wishlist: [...state.wishlist, item] 
    })),
  removeFromWishlist: (id) =>
    set((state) => ({
      wishlist: state.wishlist.filter((item) => item.id !== id)
    })),
  isAdmin: false,
  setIsAdmin: (value) => set({ isAdmin: value }),
}));