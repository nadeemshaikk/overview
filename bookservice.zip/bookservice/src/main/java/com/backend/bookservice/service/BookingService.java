package com.backend.bookservice.service;

import com.backend.bookservice.model.Booking;

import java.util.List;

public interface BookingService {
    Booking createBooking(Booking booking);
    List<Booking> getAllBookings();
    List<Booking> getBookingsByUserId(String userId);
}
