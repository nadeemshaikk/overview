package com.backend.bookservice.dto;

import java.util.Date;

public class BookingDTO {
    private Long id;
    private String providerId;
    private String serviceId;
    private String userId;
    private Date bookingDate;
    private boolean status;
    private String make;
    private String carModel;
    private String contactNo;

    public BookingDTO() {}

    public BookingDTO(Long id, String providerId, String serviceId, String userId, Date bookingDate,
                      boolean status, String make, String carModel, String contactNo) {
        this.id = id;
        this.providerId = providerId;
        this.serviceId = serviceId;
        this.userId = userId;
        this.bookingDate = bookingDate;
        this.status = status;
        this.make = make;
        this.carModel = carModel;
        this.contactNo = contactNo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }
}
