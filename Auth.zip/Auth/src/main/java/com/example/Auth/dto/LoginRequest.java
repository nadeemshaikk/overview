package com.example.Auth.dto;

public record LoginRequest(String userName, String password) {
}
